import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DashboardOverview } from './components/DashboardOverview';
import { NetworkMap } from './components/NetworkMap';
import { FacilityInventoryTable } from './components/FacilityInventoryTable';
import { EarlyWarningForecast } from './components/EarlyWarningForecast';
import { RedistributionConsole } from './components/RedistributionConsole';
import { FederatedConsensusView } from './components/FederatedConsensusView';
import { FacilityDetailDrawer } from './components/FacilityDetailDrawer';
import { AiDirectiveModal } from './components/AiDirectiveModal';

import { 
  HealthFacility, 
  TransferManifest, 
  EmergencyScenario, 
  FederatedParticipantNode, 
  FederatedRoundLog,
  CrisisDirectiveResponse 
} from './types';
import { 
  INITIAL_FACILITIES, 
  INITIAL_BRICS_NODES, 
  INITIAL_ROUND_LOGS 
} from './data/mockHealthData';
import { 
  generateAutomatedRedistribution, 
  applyTransferDelivery 
} from './services/redistributionEngine';
import { executeFederatedRound } from './services/federatedEngine';
import { requestAiCrisisDirective } from './services/geminiService';

export default function App() {
  const [activeTab, setActiveTab] = useState<'network' | 'forecast' | 'redistribution' | 'federated'>('network');
  const [activeScenario, setActiveScenario] = useState<EmergencyScenario>('baseline');
  const [facilities, setFacilities] = useState<HealthFacility[]>(INITIAL_FACILITIES);
  const [transfers, setTransfers] = useState<TransferManifest[]>([]);
  const [selectedFacility, setSelectedFacility] = useState<HealthFacility | null>(null);

  // Federated learning state
  const [nodes, setNodes] = useState<FederatedParticipantNode[]>(INITIAL_BRICS_NODES);
  const [roundLogs, setRoundLogs] = useState<FederatedRoundLog[]>(INITIAL_ROUND_LOGS);
  const [isAggregating, setIsAggregating] = useState<boolean>(false);

  // AI Crisis Directive Modal State
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);
  const [aiDirective, setAiDirective] = useState<CrisisDirectiveResponse | null>(null);
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);

  // Initialize and recompute automated cross-district redistribution
  useEffect(() => {
    const generated = generateAutomatedRedistribution(facilities);
    setTransfers(generated);
  }, []);

  // Handle Scenario Transitions (Monsoon Dengue, Flood & Cholera, Cold Chain Power Failure, Respiratory Surge)
  const handleScenarioChange = (scenario: EmergencyScenario) => {
    setActiveScenario(scenario);

    const updated = facilities.map(f => {
      const cloned = JSON.parse(JSON.stringify(f)) as HealthFacility;

      if (scenario === 'monsoon_dengue') {
        cloned.todayFootfall = Math.round(f.avgDailyFootfall * 1.6);
        cloned.feverClinicSurgeRate = 185;
        cloned.medicines = cloned.medicines.map(m => {
          if (m.name.includes('Artemether') || m.name.includes('Ringer') || m.name.includes('Normal Saline')) {
            const newBurn = Math.round(m.dailyBurnRate * 2.2);
            const daysRemaining = Math.max(0.8, Math.round((m.currentStock / newBurn) * 10) / 10);
            return {
              ...m,
              dailyBurnRate: newBurn,
              daysOfStockRemaining: daysRemaining,
              status: daysRemaining <= 3 ? 'critical' : daysRemaining <= 7 ? 'low' : m.status,
            };
          }
          return m;
        });
        cloned.beds.occupied = Math.min(cloned.beds.total, Math.round(cloned.beds.occupied * 1.3));
        cloned.beds.occupancyRate = Math.round((cloned.beds.occupied / cloned.beds.total) * 100);
      } else if (scenario === 'flood_cholera') {
        cloned.todayFootfall = Math.round(f.avgDailyFootfall * 1.8);
        cloned.feverClinicSurgeRate = 210;
        cloned.medicines = cloned.medicines.map(m => {
          if (m.name.includes('ORS') || m.name.includes('Ringer') || m.name.includes('Amoxicillin')) {
            const newBurn = Math.round(m.dailyBurnRate * 2.5);
            const daysRemaining = Math.max(0.6, Math.round((m.currentStock / newBurn) * 10) / 10);
            return {
              ...m,
              dailyBurnRate: newBurn,
              daysOfStockRemaining: daysRemaining,
              status: daysRemaining <= 3 ? 'critical' : daysRemaining <= 7 ? 'low' : m.status,
            };
          }
          return m;
        });
      } else if (scenario === 'cold_chain_failure') {
        if (f.tier === 'PHC') {
          cloned.powerColdChainStatus = 'battery_backup';
          cloned.medicines = cloned.medicines.map(m => {
            if (m.requiresColdChain) {
              return { ...m, coldChainTempC: 7.6, status: 'critical' };
            }
            return m;
          });
        }
      } else if (scenario === 'respiratory_surge') {
        cloned.todayFootfall = Math.round(f.avgDailyFootfall * 1.5);
        cloned.feverClinicSurgeRate = 160;
        cloned.medicines = cloned.medicines.map(m => {
          if (m.name.includes('Azithromycin') || m.name.includes('Amoxicillin')) {
            const newBurn = Math.round(m.dailyBurnRate * 2.0);
            const daysRemaining = Math.max(1.2, Math.round((m.currentStock / newBurn) * 10) / 10);
            return {
              ...m,
              dailyBurnRate: newBurn,
              daysOfStockRemaining: daysRemaining,
              status: daysRemaining <= 3 ? 'critical' : daysRemaining <= 7 ? 'low' : m.status,
            };
          }
          return m;
        });
      } else {
        // Reset to initial
        const original = INITIAL_FACILITIES.find(init => init.id === f.id);
        return original ? JSON.parse(JSON.stringify(original)) : cloned;
      }

      return cloned;
    });

    setFacilities(updated);
    const newManifests = generateAutomatedRedistribution(updated);
    setTransfers(newManifests);
  };

  // Authorize a single transfer manifest
  const handleAuthorizeManifest = (manifestId: string) => {
    setTransfers(prev => prev.map(m => {
      if (m.id === manifestId) {
        return { ...m, status: 'authorized' };
      }
      return m;
    }));
  };

  // Dispatch a cold chain vehicle
  const handleDispatchManifest = (manifestId: string) => {
    setTransfers(prev => prev.map(m => {
      if (m.id === manifestId) {
        return { 
          ...m, 
          status: 'in_transit', 
          dispatchedAt: 'Just now' 
        };
      }
      return m;
    }));
  };

  // Confirm delivery of transferred supplies & restock inventory
  const handleDeliverManifest = (manifestId: string) => {
    const targetManifest = transfers.find(m => m.id === manifestId);
    if (!targetManifest) return;

    // Apply delivery to facilities stock
    const updatedFacilities = applyTransferDelivery(facilities, targetManifest);
    setFacilities(updatedFacilities);

    // Mark manifest as delivered
    setTransfers(prev => prev.map(m => {
      if (m.id === manifestId) {
        return { 
          ...m, 
          status: 'delivered', 
          completedAt: 'Just now' 
        };
      }
      return m;
    }));

    // If inspected facility is recipient, update selection
    if (selectedFacility && selectedFacility.id === targetManifest.destFacilityId) {
      const refreshed = updatedFacilities.find(f => f.id === selectedFacility.id);
      if (refreshed) setSelectedFacility(refreshed);
    }
  };

  // Authorize all suggested manifests at once
  const handleAuthorizeAll = () => {
    setTransfers(prev => prev.map(m => {
      if (m.status === 'suggested') {
        return { ...m, status: 'authorized' };
      }
      return m;
    }));
  };

  // Re-run matching algorithm manually
  const handleRecalculateRedistribution = () => {
    const newManifests = generateAutomatedRedistribution(facilities);
    setTransfers(newManifests);
  };

  // Trigger Federated Consensus Round
  const handleTriggerFederatedRound = () => {
    setIsAggregating(true);

    setTimeout(() => {
      const nextRoundNum = (roundLogs[0]?.roundNumber || 41) + 1;
      const result = executeFederatedRound(nodes, roundLogs, nextRoundNum);

      setNodes(result.updatedNodes);
      setRoundLogs([result.newRoundLog, ...roundLogs]);
      setIsAggregating(false);
    }, 1200);
  };

  // Trigger AI Crisis Directive
  const handleOpenAiDirective = async () => {
    setIsAiModalOpen(true);
    setIsAiLoading(true);

    const deficitFacilities = facilities.filter(f => f.medicines.some(m => m.daysOfStockRemaining <= 3));
    const surplusFacilities = facilities.filter(f => f.medicines.some(m => m.daysOfStockRemaining > 35));

    const criticalItems = Array.from(new Set(
      deficitFacilities.flatMap(f => f.medicines.filter(m => m.daysOfStockRemaining <= 3).map(m => m.name))
    ));

    const result = await requestAiCrisisDirective({
      scenario: activeScenario,
      district: facilities[0]?.district || 'Satara/Pune Health Corridor',
      criticalItems,
      deficitCount: deficitFacilities.length,
      surplusCount: surplusFacilities.length,
    });

    setAiDirective(result);
    setIsAiLoading(false);
  };

  // Calculate count of critical alerts
  const criticalAlertCount = facilities.filter(f => 
    f.medicines.some(m => m.daysOfStockRemaining <= 3)
  ).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* 3-Zone Header Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeScenario={activeScenario}
        onScenarioChange={handleScenarioChange}
        onOpenAiDirective={handleOpenAiDirective}
        criticalAlertCount={criticalAlertCount}
      />

      {/* Main App Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {/* Top Resilience Overview Stats */}
        <DashboardOverview
          facilities={facilities}
          transfers={transfers}
        />

        {/* View 1: PHC Network Map & Stock Registry */}
        {activeTab === 'network' && (
          <div className="space-y-6">
            <NetworkMap
              facilities={facilities}
              transfers={transfers}
              onSelectFacility={(fac) => setSelectedFacility(fac)}
              selectedFacility={selectedFacility}
            />

            <FacilityInventoryTable
              facilities={facilities}
              onSelectFacility={(fac) => setSelectedFacility(fac)}
              selectedFacility={selectedFacility}
            />
          </div>
        )}

        {/* View 2: Demand Forecasting & Early Warnings */}
        {activeTab === 'forecast' && (
          <EarlyWarningForecast
            facilities={facilities}
            activeScenario={activeScenario}
            onScenarioChange={handleScenarioChange}
            onSelectFacility={(fac) => setSelectedFacility(fac)}
          />
        )}

        {/* View 3: Cross-District Resource Redistribution */}
        {activeTab === 'redistribution' && (
          <RedistributionConsole
            manifests={transfers}
            facilities={facilities}
            onAuthorizeManifest={handleAuthorizeManifest}
            onDispatchManifest={handleDispatchManifest}
            onDeliverManifest={handleDeliverManifest}
            onAuthorizeAll={handleAuthorizeAll}
            onRecalculateRedistribution={handleRecalculateRedistribution}
          />
        )}

        {/* View 4: BRICS Federated AI Consortium */}
        {activeTab === 'federated' && (
          <FederatedConsensusView
            nodes={nodes}
            roundLogs={roundLogs}
            onTriggerFederatedRound={handleTriggerFederatedRound}
            isAggregating={isAggregating}
          />
        )}
      </main>

      {/* Facility Inspection Drawer */}
      <FacilityDetailDrawer
        facility={selectedFacility}
        onClose={() => setSelectedFacility(null)}
        onRequestReallocation={() => {
          setActiveTab('redistribution');
        }}
      />

      {/* AI Crisis Logistics Directive Modal */}
      <AiDirectiveModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        directive={aiDirective}
        isLoading={isAiLoading}
        onRegenerate={handleOpenAiDirective}
        activeScenario={activeScenario}
        deficitCount={criticalAlertCount}
      />

      {/* Quiet, Clean Editorial Footer (Anti-Slop Compliance) */}
      <footer className="border-t border-slate-900 bg-slate-950 px-6 py-4 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div>
          <span>BRICS HealthResilience Framework</span>
          <span aria-hidden="true" className="mx-2">·</span>
          <span>National PHC Mesh & Sovereign Federated Learning Architecture</span>
        </div>
        <div className="text-[11px] font-mono text-slate-500">
          Telemetry active · Rényi Differential Privacy ε = 0.82
        </div>
      </footer>
    </div>
  );
}
