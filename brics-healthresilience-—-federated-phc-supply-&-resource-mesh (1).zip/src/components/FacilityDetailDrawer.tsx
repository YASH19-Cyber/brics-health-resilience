import React from 'react';
import { HealthFacility } from '../types';
import { X, Bed, Pill, Users, Thermometer, ShieldAlert, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';

interface FacilityDetailDrawerProps {
  facility: HealthFacility | null;
  onClose: () => void;
  onRequestReallocation?: (facility: HealthFacility) => void;
}

export const FacilityDetailDrawer: React.FC<FacilityDetailDrawerProps> = ({
  facility,
  onClose,
  onRequestReallocation,
}) => {
  if (!facility) return null;

  const criticalMeds = facility.medicines.filter(m => m.daysOfStockRemaining <= 3);
  const lowMeds = facility.medicines.filter(m => m.daysOfStockRemaining > 3 && m.daysOfStockRemaining <= 7);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/70 backdrop-blur-sm flex justify-end">
      <div 
        className="w-full max-w-2xl bg-slate-900 border-l border-slate-800 h-full overflow-y-auto p-6 shadow-2xl flex flex-col justify-between"
      >
        <div>
          {/* Top Bar */}
          <div className="flex items-start justify-between pb-4 border-b border-slate-800 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-mono text-xs font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded">
                  {facility.tier}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  {facility.code}
                </span>
              </div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                {facility.name}
              </h2>
              <div className="text-xs text-slate-400 mt-0.5">
                {facility.subDistrict} · {facility.district} District · Catchment Pop: {facility.catchmentPopulation.toLocaleString()}
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800/80">
              <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
                <span>Today's Footfall</span>
                <Users className="h-3.5 w-3.5 text-slate-400" />
              </div>
              <div className="text-lg font-bold text-white font-mono tabular-nums">
                {facility.todayFootfall}
              </div>
              <div className="text-[10px] text-slate-400">
                Surge: +{facility.feverClinicSurgeRate}%
              </div>
            </div>

            <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800/80">
              <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
                <span>Bed Occupancy</span>
                <Bed className="h-3.5 w-3.5 text-slate-400" />
              </div>
              <div className="text-lg font-bold text-white font-mono tabular-nums">
                {facility.beds.occupancyRate}%
              </div>
              <div className="text-[10px] text-slate-400">
                {facility.beds.occupied} of {facility.beds.total} beds
              </div>
            </div>

            <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800/80">
              <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
                <span>Doctors on Duty</span>
                <Users className="h-3.5 w-3.5 text-slate-400" />
              </div>
              <div className="text-lg font-bold text-white font-mono tabular-nums">
                {facility.personnel.medicalOfficers.present}/{facility.personnel.medicalOfficers.sanctioned}
              </div>
              <div className="text-[10px] text-slate-400">
                {facility.personnel.shiftStatus}
              </div>
            </div>
          </div>

          {/* Section 1: Medicine Stocks & Essential Supplies */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Pill className="h-4 w-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-white">
                  Essential Medicine Inventory ({facility.medicines.length} Tracked Formulations)
                </h3>
              </div>
              <span className="text-xs text-slate-400">
                Days of Stock Remaining (DoSR)
              </span>
            </div>

            <div className="space-y-2">
              {facility.medicines.map((med) => {
                const isCritical = med.daysOfStockRemaining <= 3;
                const isLow = med.daysOfStockRemaining > 3 && med.daysOfStockRemaining <= 7;
                const isSurplus = med.daysOfStockRemaining > 35;

                return (
                  <div
                    key={med.id || med.name}
                    className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg flex items-center justify-between gap-4 text-xs"
                  >
                    <div>
                      <div className="font-semibold text-slate-200">
                        {med.name}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <span>{med.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>Batch: {med.batchNumber}</span>
                        {med.requiresColdChain && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-cyan-400 font-mono">
                              Cold Chain {med.coldChainTempC ? `${med.coldChainTempC}°C` : '4°C'}
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="flex items-baseline justify-end gap-1.5 font-mono tabular-nums">
                        <span
                          className={`font-bold text-sm ${
                            isCritical ? 'text-rose-400' : isLow ? 'text-amber-400' : isSurplus ? 'text-blue-400' : 'text-emerald-400'
                          }`}
                        >
                          {med.daysOfStockRemaining}d
                        </span>
                        <span className="text-slate-400 text-[11px]">
                          ({med.currentStock} {med.unit})
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Burn: {med.dailyBurnRate} {med.unit}/day
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 2: Bed Allocation Wards */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-800">
              <Bed className="h-4 w-4 text-blue-400" />
              <h3 className="text-sm font-semibold text-white">
                Ward Bed Breakdown ({facility.beds.total} Total Sanctioned)
              </h3>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="p-2.5 bg-slate-950/60 rounded border border-slate-800">
                <div className="text-[11px] text-slate-400">Stabilization Beds</div>
                <div className="font-mono font-bold text-white mt-1">
                  {facility.beds.stabilizationBeds.occupied} / {facility.beds.stabilizationBeds.total}
                </div>
              </div>
              <div className="p-2.5 bg-slate-950/60 rounded border border-slate-800">
                <div className="text-[11px] text-slate-400">Maternity Delivery</div>
                <div className="font-mono font-bold text-white mt-1">
                  {facility.beds.maternityBeds.occupied} / {facility.beds.maternityBeds.total}
                </div>
              </div>
              <div className="p-2.5 bg-slate-950/60 rounded border border-slate-800">
                <div className="text-[11px] text-slate-400">Pediatric Beds</div>
                <div className="font-mono font-bold text-white mt-1">
                  {facility.beds.pediatricBeds.occupied} / {facility.beds.pediatricBeds.total}
                </div>
              </div>
              <div className="p-2.5 bg-slate-950/60 rounded border border-slate-800">
                <div className="text-[11px] text-slate-400">Infectious Isolation</div>
                <div className="font-mono font-bold text-white mt-1">
                  {facility.beds.isolationBeds.occupied} / {facility.beds.isolationBeds.total}
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Personnel Roster */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-800">
              <Users className="h-4 w-4 text-emerald-400" />
              <h3 className="text-sm font-semibold text-white">
                Frontline Clinical Roster Attendance ({facility.personnel.overallAttendanceRate}%)
              </h3>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              <div className="p-2 bg-slate-950/60 rounded border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">Medical Officers:</span>
                <span className="font-mono font-semibold text-white tabular-nums">
                  {facility.personnel.medicalOfficers.present}/{facility.personnel.medicalOfficers.sanctioned}
                </span>
              </div>
              <div className="p-2 bg-slate-950/60 rounded border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">Staff Nurses:</span>
                <span className="font-mono font-semibold text-white tabular-nums">
                  {facility.personnel.staffNurses.present}/{facility.personnel.staffNurses.sanctioned}
                </span>
              </div>
              <div className="p-2 bg-slate-950/60 rounded border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">ANM Midwives:</span>
                <span className="font-mono font-semibold text-white tabular-nums">
                  {facility.personnel.anmMidwives.present}/{facility.personnel.anmMidwives.sanctioned}
                </span>
              </div>
              <div className="p-2 bg-slate-950/60 rounded border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">Lab Technicians:</span>
                <span className="font-mono font-semibold text-white tabular-nums">
                  {facility.personnel.labTechnicians.present}/{facility.personnel.labTechnicians.sanctioned}
                </span>
              </div>
              <div className="p-2 bg-slate-950/60 rounded border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">Pharmacists:</span>
                <span className="font-mono font-semibold text-white tabular-nums">
                  {facility.personnel.pharmacists.present}/{facility.personnel.pharmacists.sanctioned}
                </span>
              </div>
              <div className="p-2 bg-slate-950/60 rounded border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">Shift Status:</span>
                <span className="text-slate-200 font-medium">
                  {facility.personnel.shiftStatus}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Drawer Actions */}
        <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-400">
            Last Telemetry Ping: {facility.lastTelemetryPing}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors cursor-pointer"
            >
              Close
            </button>
            {onRequestReallocation && (criticalMeds.length > 0 || lowMeds.length > 0) && (
              <button
                onClick={() => {
                  onRequestReallocation(facility);
                  onClose();
                }}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-md transition-colors shadow-sm cursor-pointer"
              >
                Trigger Automated Reallocation
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
