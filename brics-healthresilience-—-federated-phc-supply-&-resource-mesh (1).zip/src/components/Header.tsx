import React from 'react';
import { ShieldAlert, Sparkles, Activity } from 'lucide-react';
import { EmergencyScenario } from '../types';

interface HeaderProps {
  activeTab: 'network' | 'forecast' | 'redistribution' | 'federated';
  setActiveTab: (tab: 'network' | 'forecast' | 'redistribution' | 'federated') => void;
  activeScenario: EmergencyScenario;
  onScenarioChange: (scenario: EmergencyScenario) => void;
  onOpenAiDirective: () => void;
  criticalAlertCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  activeScenario,
  onScenarioChange,
  onOpenAiDirective,
  criticalAlertCount,
}) => {
  return (
    <header className="sticky top-0 z-40 flex items-center justify-between border-b border-slate-800 bg-slate-950/90 px-6 py-3.5 backdrop-blur-md">
      {/* Zone 1: Brand Title (Single text element wordmark) */}
      <div className="flex items-center gap-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
          <Activity className="h-4 w-4" />
        </div>
        <button 
          onClick={() => setActiveTab('network')} 
          className="text-left group cursor-pointer focus:outline-none"
        >
          <span className="text-base font-bold tracking-tight text-white group-hover:text-emerald-300 transition-colors">
            BRICS HealthResilience
          </span>
          <span className="hidden sm:inline-block ml-2 text-xs text-slate-400 font-normal">
            National Federated PHC Logistics Mesh
          </span>
        </button>
      </div>

      {/* Zone 2: 4 clean text navigation links */}
      <nav className="hidden md:flex items-center gap-1 bg-slate-900/80 p-1 rounded-lg border border-slate-800/80">
        <button
          onClick={() => setActiveTab('network')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'network'
              ? 'bg-slate-800 text-white shadow-sm border border-slate-700/50'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          PHC Network & Stock
        </button>
        <button
          onClick={() => setActiveTab('forecast')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'forecast'
              ? 'bg-slate-800 text-white shadow-sm border border-slate-700/50'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>Demand Forecast</span>
          {criticalAlertCount > 0 && (
            <span className="h-1.5 w-1.5 rounded-full bg-rose-500 animate-pulse" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('redistribution')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'redistribution'
              ? 'bg-slate-800 text-white shadow-sm border border-slate-700/50'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Resource Redistribution
        </button>
        <button
          onClick={() => setActiveTab('federated')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'federated'
              ? 'bg-slate-800 text-white shadow-sm border border-slate-700/50'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          BRICS Federated AI
        </button>
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-3">
        {/* Emergency Scenario Selector */}
        <div className="flex items-center gap-2">
          <label htmlFor="scenario-select" className="hidden lg:inline text-xs text-slate-400 whitespace-nowrap">
            Epidemic Vector:
          </label>
          <select
            id="scenario-select"
            value={activeScenario}
            onChange={(e) => onScenarioChange(e.target.value as EmergencyScenario)}
            aria-label="Epidemic Vector Scenario"
            className="text-xs bg-slate-900 border border-slate-700 rounded-md px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            <option value="baseline">Baseline Surveillance</option>
            <option value="monsoon_dengue">Monsoon Dengue Spike</option>
            <option value="flood_cholera">Flood & Diarrheal Outbreak</option>
            <option value="respiratory_surge">Viral Respiratory Surge</option>
            <option value="cold_chain_failure">Cold-Chain Power Hazard</option>
          </select>
        </div>

        {/* AI Crisis Directive Trigger */}
        <button
          onClick={onOpenAiDirective}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 rounded-md hover:bg-emerald-300 transition-colors shadow-sm whitespace-nowrap cursor-pointer"
        >
          <Sparkles className="h-3.5 w-3.5" />
          <span>AI Directive</span>
        </button>
      </div>
    </header>
  );
};
