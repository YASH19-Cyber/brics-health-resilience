import React from 'react';
import { Pill, Bed, Users, Truck, AlertTriangle, ShieldCheck, Zap } from 'lucide-react';
import { HealthFacility, TransferManifest } from '../types';

interface DashboardOverviewProps {
  facilities: HealthFacility[];
  transfers: TransferManifest[];
  onFilterStatus?: (status: string) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  facilities,
  transfers,
}) => {
  // Aggregate real telemetry metrics
  const totalFacilities = facilities.length;
  const criticalStockoutCount = facilities.filter(f => 
    f.medicines.some(m => m.daysOfStockRemaining <= 3)
  ).length;

  const totalBeds = facilities.reduce((acc, f) => acc + f.beds.total, 0);
  const occupiedBeds = facilities.reduce((acc, f) => acc + f.beds.occupied, 0);
  const overallBedOccupancy = Math.round((occupiedBeds / (totalBeds || 1)) * 100);

  const totalSanctionedStaff = facilities.reduce((acc, f) => 
    acc + f.personnel.medicalOfficers.sanctioned + f.personnel.staffNurses.sanctioned + f.personnel.anmMidwives.sanctioned, 0
  );
  const totalPresentStaff = facilities.reduce((acc, f) => 
    acc + f.personnel.medicalOfficers.present + f.personnel.staffNurses.present + f.personnel.anmMidwives.present, 0
  );
  const overallStaffingRate = Math.round((totalPresentStaff / (totalSanctionedStaff || 1)) * 100);

  const activeTransfers = transfers.filter(t => t.status === 'in_transit' || t.status === 'authorized').length;
  const deliveredTransfers = transfers.filter(t => t.status === 'delivered').length;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {/* Metric 1: Medicine Stockout Risk */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4 transition-all hover:border-slate-700">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <span className="font-medium text-slate-300">Medicine Stockout Vulnerability</span>
          <Pill className={`h-4 w-4 ${criticalStockoutCount > 0 ? 'text-rose-400' : 'text-emerald-400'}`} />
        </div>
        <div className="flex items-baseline gap-2 mb-1">
          <span className="text-2xl font-bold tracking-tight text-white tabular-nums">
            {criticalStockoutCount}
          </span>
          <span className="text-xs text-slate-400">
            of {totalFacilities} PHCs at risk
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <span className={criticalStockoutCount > 0 ? 'text-rose-400 font-medium' : 'text-emerald-400 font-medium'}>
            {criticalStockoutCount > 0 ? 'Urgent dispatch required' : 'Stock levels adequate'}
          </span>
          <span aria-hidden="true">·</span>
          <span>&lt;3 days supply buffer</span>
        </div>
      </div>

      {/* Metric 2: Bed Capacity & Occupancy */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4 transition-all hover:border-slate-700">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <span className="font-medium text-slate-300">National Bed Occupancy</span>
          <Bed className={`h-4 w-4 ${overallBedOccupancy >= 85 ? 'text-amber-400' : 'text-blue-400'}`} />
        </div>
        <div className="flex items-baseline gap-2 mb-1">
          <span className="text-2xl font-bold tracking-tight text-white tabular-nums">
            {overallBedOccupancy}%
          </span>
          <span className="text-xs text-slate-400 tabular-nums">
            ({occupiedBeds} / {totalBeds} beds)
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <span>{totalBeds - occupiedBeds} stabilization beds open</span>
          <span aria-hidden="true">·</span>
          <span>Maternity & Pediatric</span>
        </div>
      </div>

      {/* Metric 3: Personnel Attendance */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4 transition-all hover:border-slate-700">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <span className="font-medium text-slate-300">Frontline Medical Attendance</span>
          <Users className={`h-4 w-4 ${overallStaffingRate < 80 ? 'text-amber-400' : 'text-emerald-400'}`} />
        </div>
        <div className="flex items-baseline gap-2 mb-1">
          <span className="text-2xl font-bold tracking-tight text-white tabular-nums">
            {overallStaffingRate}%
          </span>
          <span className="text-xs text-slate-400 tabular-nums">
            ({totalPresentStaff} on duty / {totalSanctionedStaff})
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <span>Doctors & Staff Nurses</span>
          <span aria-hidden="true">·</span>
          <span>ANM field coverage 91%</span>
        </div>
      </div>

      {/* Metric 4: Automated Redistribution */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4 transition-all hover:border-slate-700">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <span className="font-medium text-slate-300">Inter-District Reallocation</span>
          <Truck className="h-4 w-4 text-emerald-400" />
        </div>
        <div className="flex items-baseline gap-2 mb-1">
          <span className="text-2xl font-bold tracking-tight text-white tabular-nums">
            {activeTransfers} Active
          </span>
          <span className="text-xs text-slate-400 tabular-nums">
            · {deliveredTransfers} completed
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <span className="text-emerald-400 font-medium">Surplus matching active</span>
          <span aria-hidden="true">·</span>
          <span>Cold-chain verified</span>
        </div>
      </div>
    </div>
  );
};
