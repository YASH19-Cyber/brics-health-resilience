import React, { useState } from 'react';
import { TransferManifest, HealthFacility } from '../types';
import { Truck, ArrowRight, ShieldCheck, CheckCircle2, Clock, MapPin, RefreshCw, Send, AlertTriangle } from 'lucide-react';

interface RedistributionConsoleProps {
  manifests: TransferManifest[];
  facilities: HealthFacility[];
  onAuthorizeManifest: (manifestId: string) => void;
  onDispatchManifest: (manifestId: string) => void;
  onDeliverManifest: (manifestId: string) => void;
  onAuthorizeAll: () => void;
  onRecalculateRedistribution: () => void;
}

export const RedistributionConsole: React.FC<RedistributionConsoleProps> = ({
  manifests,
  facilities,
  onAuthorizeManifest,
  onDispatchManifest,
  onDeliverManifest,
  onAuthorizeAll,
  onRecalculateRedistribution,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | 'suggested' | 'in_transit' | 'delivered'>('all');

  const filteredManifests = manifests.filter(m => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'in_transit') return m.status === 'in_transit' || m.status === 'authorized';
    return m.status === filterStatus;
  });

  const suggestedCount = manifests.filter(m => m.status === 'suggested').length;
  const inTransitCount = manifests.filter(m => m.status === 'in_transit' || m.status === 'authorized').length;
  const deliveredCount = manifests.filter(m => m.status === 'delivered').length;

  return (
    <div className="space-y-6">
      {/* Top Header & Re-optimization Control */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2">
              <Truck className="h-4 w-4 text-emerald-400" />
              <span>Automated Cross-District Resource Redistribution Engine</span>
            </h2>
            <p className="text-xs text-slate-400">
              Algorithmic matching of regional surplus hubs to deficit PHCs without depleting donor safety buffers
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onRecalculateRedistribution}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>Re-evaluate Mesh</span>
            </button>

            {suggestedCount > 0 && (
              <button
                onClick={onAuthorizeAll}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-md transition-colors shadow-sm"
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>Authorize All ({suggestedCount})</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Filters */}
        <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-800/80">
          <span className="text-xs text-slate-400 mr-2">Filter Manifests:</span>
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
              filterStatus === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Manifests ({manifests.length})
          </button>
          <button
            onClick={() => setFilterStatus('suggested')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
              filterStatus === 'suggested' ? 'bg-amber-950/80 text-amber-300 border border-amber-800/40' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Pending Approval ({suggestedCount})
          </button>
          <button
            onClick={() => setFilterStatus('in_transit')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
              filterStatus === 'in_transit' ? 'bg-blue-950/80 text-blue-300 border border-blue-800/40' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            En Route ({inTransitCount})
          </button>
          <button
            onClick={() => setFilterStatus('delivered')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
              filterStatus === 'delivered' ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/40' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Delivered ({deliveredCount})
          </button>
        </div>
      </div>

      {/* Manifest Cards Grid */}
      <div className="space-y-4">
        {filteredManifests.length === 0 ? (
          <div className="rounded-lg border border-slate-800 bg-slate-900/40 p-12 text-center text-slate-400 text-xs">
            <CheckCircle2 className="h-8 w-8 text-emerald-400 mx-auto mb-2 opacity-80" />
            <div className="text-slate-200 font-medium text-sm mb-1">
              No active transfer manifests for this filter
            </div>
            <div>All primary care facilities are currently operating above critical safety thresholds.</div>
          </div>
        ) : (
          filteredManifests.map((manifest) => {
            const isDelivered = manifest.status === 'delivered';
            const isInTransit = manifest.status === 'in_transit';
            const isAuthorized = manifest.status === 'authorized';
            const isSuggested = manifest.status === 'suggested';

            return (
              <div
                key={manifest.id}
                className={`rounded-lg border transition-all p-4 ${
                  isDelivered
                    ? 'border-emerald-900/50 bg-emerald-950/10'
                    : isInTransit
                    ? 'border-blue-800/80 bg-blue-950/20'
                    : isAuthorized
                    ? 'border-indigo-800/80 bg-indigo-950/20'
                    : 'border-slate-800 bg-slate-900/60'
                }`}
              >
                {/* Manifest Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-800/80">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-bold text-white bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {manifest.id}
                    </span>
                    <div className="text-xs text-slate-400">
                      <span>Created {manifest.createdAt}</span>
                      <span aria-hidden="true" className="mx-1.5">·</span>
                      <span className="text-slate-300">{manifest.vehicleType}</span>
                    </div>
                  </div>

                  {/* Status Indicator */}
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs font-semibold ${
                        isDelivered
                          ? 'text-emerald-400'
                          : isInTransit
                          ? 'text-blue-400'
                          : isAuthorized
                          ? 'text-indigo-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {isDelivered
                        ? 'Delivered & Inventory Restocked'
                        : isInTransit
                        ? 'In Transit (En Route)'
                        : isAuthorized
                        ? 'Authorized — Dispatch Imminent'
                        : 'Suggested by Logistics Engine'}
                    </span>
                  </div>
                </div>

                {/* Corridor & Transfer Details */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center mb-4">
                  {/* Source Donor Hub */}
                  <div className="md:col-span-4 p-3 rounded-lg bg-slate-950/70 border border-slate-800/80">
                    <div className="text-[11px] text-blue-400 font-medium uppercase tracking-wider mb-0.5">
                      Origin Surplus Hub
                    </div>
                    <div className="font-semibold text-xs text-white">
                      {manifest.sourceFacilityName}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {manifest.sourceDistrict} District
                    </div>
                  </div>

                  {/* Transit Metrics & Arrow */}
                  <div className="md:col-span-4 flex flex-col items-center justify-center text-center px-2">
                    <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
                      <Truck className={`h-4 w-4 ${isInTransit ? 'text-blue-400 animate-bounce' : 'text-slate-400'}`} />
                      <span className="font-mono tabular-nums">{manifest.distanceKm} km</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">~{manifest.estimatedTransitMinutes} mins</span>
                    </div>
                    <div className="w-full flex items-center gap-2">
                      <div className="h-0.5 flex-1 bg-slate-700" />
                      <ArrowRight className="h-4 w-4 text-emerald-400 shrink-0" />
                      <div className="h-0.5 flex-1 bg-slate-700" />
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono mt-1">
                      Courier: {manifest.courierName}
                    </div>
                  </div>

                  {/* Destination Deficit PHC */}
                  <div className="md:col-span-4 p-3 rounded-lg bg-slate-950/70 border border-slate-800/80">
                    <div className="text-[11px] text-rose-400 font-medium uppercase tracking-wider mb-0.5">
                      Target Deficit Centre
                    </div>
                    <div className="font-semibold text-xs text-white">
                      {manifest.destFacilityName}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {manifest.destDistrict} District (Depletion in {manifest.projectedStockoutHours}h)
                    </div>
                  </div>
                </div>

                {/* Items Manifest Table */}
                <div className="p-3 bg-slate-950/50 rounded-lg border border-slate-800/70 mb-4">
                  <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold mb-2">
                    Transferred Medicine & Medical Supplies
                  </div>
                  <div className="space-y-1.5">
                    {manifest.items.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-slate-200">{item.medicineName}</span>
                          {item.requiresColdChain && (
                            <span className="text-[10px] text-cyan-400 font-mono">
                              [2°C–8°C Cold Chain]
                            </span>
                          )}
                        </div>
                        <div className="font-mono tabular-nums font-semibold text-emerald-400">
                          +{item.quantity} {item.unit}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Controls */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <div className="text-xs text-slate-400">
                    Safety Margin Rule: Donor retains minimum 18-day stock reserve.
                  </div>

                  <div className="flex items-center gap-2">
                    {isSuggested && (
                      <button
                        onClick={() => onAuthorizeManifest(manifest.id)}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-md transition-colors"
                      >
                        <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                        <span>Authorize Manifest</span>
                      </button>
                    )}

                    {isAuthorized && (
                      <button
                        onClick={() => onDispatchManifest(manifest.id)}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors shadow-sm"
                      >
                        <Send className="h-3.5 w-3.5" />
                        <span>Dispatch Cold-Chain Van</span>
                      </button>
                    )}

                    {isInTransit && (
                      <button
                        onClick={() => onDeliverManifest(manifest.id)}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-md transition-colors shadow-sm"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>Confirm Delivery & Restock</span>
                      </button>
                    )}

                    {isDelivered && (
                      <span className="inline-flex items-center gap-1 text-xs text-emerald-400 font-medium">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>Restock Confirmed</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
