import React, { useState } from 'react';
import { FederatedParticipantNode, FederatedRoundLog } from '../types';
import { Globe, Shield, Cpu, RefreshCw, CheckCircle2, Lock, ArrowUpRight, BarChart2, Layers } from 'lucide-react';

interface FederatedConsensusViewProps {
  nodes: FederatedParticipantNode[];
  roundLogs: FederatedRoundLog[];
  onTriggerFederatedRound: () => void;
  isAggregating: boolean;
}

export const FederatedConsensusView: React.FC<FederatedConsensusViewProps> = ({
  nodes,
  roundLogs,
  onTriggerFederatedRound,
  isAggregating,
}) => {
  const latestRound = roundLogs[0];
  const [selectedNode, setSelectedNode] = useState<FederatedParticipantNode | null>(nodes[0]);

  return (
    <div className="space-y-6">
      {/* Top Banner: Federated Architecture & Sovereign Data Shield */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Globe className="h-5 w-5 text-emerald-400" />
              <h2 className="text-base font-bold text-white tracking-tight">
                BRICS Federated AI Consortium & Sovereign Predictive Mesh
              </h2>
            </div>
            <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
              Decentralized epidemiological learning across national primary healthcare networks. 
              Zero raw patient data leaves national borders—only privacy-preserving mathematical gradient updates (<span className="font-mono text-emerald-400">ΔW</span>) are synchronized using Rényi Differential Privacy.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onTriggerFederatedRound}
              disabled={isAggregating}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 rounded-md transition-colors shadow-sm cursor-pointer whitespace-nowrap"
            >
              <RefreshCw className={`h-4 w-4 ${isAggregating ? 'animate-spin' : ''}`} />
              <span>{isAggregating ? 'Synchronizing FedAvg...' : `Execute Round #${(latestRound?.roundNumber || 41) + 1}`}</span>
            </button>
          </div>
        </div>

        {/* Global Model Health Indicators */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-slate-800">
          <div>
            <div className="text-[11px] text-slate-400">Active Consensus Round</div>
            <div className="text-lg font-bold text-white font-mono tabular-nums">
              Round #{latestRound?.roundNumber || 41}
            </div>
          </div>
          <div>
            <div className="text-[11px] text-slate-400">Global Validation Loss</div>
            <div className="text-lg font-bold text-emerald-400 font-mono tabular-nums">
              {latestRound?.globalLoss || 0.148}
            </div>
          </div>
          <div>
            <div className="text-[11px] text-slate-400">Predictive Accuracy</div>
            <div className="text-lg font-bold text-white font-mono tabular-nums">
              {latestRound?.accuracy || 94.2}%
            </div>
          </div>
          <div>
            <div className="text-[11px] text-slate-400">Differential Privacy (ε)</div>
            <div className="text-lg font-bold text-slate-200 font-mono tabular-nums flex items-center gap-1">
              <Lock className="h-3.5 w-3.5 text-emerald-400" />
              <span>0.82 ε-budget</span>
            </div>
          </div>
        </div>
      </div>

      {/* Participating National Edge Nodes */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white tracking-tight">
              Participating Sovereign Edge Clusters ({nodes.length} Nations)
            </h3>
            <p className="text-xs text-slate-400">
              Edge model parameter nodes training locally on regional PHC telemetry
            </p>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Protocol: FedAvg + Byzantine Trimming
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {nodes.map((node) => {
            const isSelected = selectedNode?.id === node.id;

            return (
              <div
                key={node.id}
                onClick={() => setSelectedNode(node)}
                className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-emerald-500/80 bg-slate-800/80'
                    : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{node.flagEmoji}</span>
                    <span className="font-semibold text-xs text-white">{node.country}</span>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-1.5 py-0.5 rounded">
                    {node.status}
                  </span>
                </div>

                <div className="text-[11px] text-slate-300 font-medium truncate mb-2">
                  {node.nationalNetwork}
                </div>

                <div className="space-y-1 text-[11px] pt-2 border-t border-slate-800/80">
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Edge PHCs Enrolled:</span>
                    <span className="font-mono text-slate-200 tabular-nums">{node.activeEdgePHCs.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Local Telemetry Ingestion:</span>
                    <span className="font-mono text-slate-200">{node.localDatasetSize}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Local Model Accuracy:</span>
                    <span className="font-mono text-emerald-400 font-semibold tabular-nums">{node.accuracyScore}%</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Weight Hash:</span>
                    <span className="font-mono text-[10px] text-slate-500">{node.modelWeightsVersion}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Transfer Learning Insights & Consensus Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Cross-Border Epidemiological Transfer Mechanism */}
        <div className="lg:col-span-5 rounded-lg border border-slate-800 bg-slate-900/60 p-4">
          <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-800">
            <Cpu className="h-4 w-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-white tracking-tight">
              Cross-National Transfer Learning Value
            </h3>
          </div>

          <div className="space-y-3 text-xs leading-relaxed text-slate-300">
            <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-md">
              <div className="font-semibold text-emerald-400 text-xs mb-1">
                Seasonal Vector-Borne Outbreak Early Warning
              </div>
              <p className="text-slate-300 text-[11px]">
                Brazil’s Southern Hemisphere arbovirus (Dengue/Zika) wave occurs 3 months prior to India’s post-monsoon surge. 
                Trained convolutional recurrent weights transferred to India’s National Health Mission edge nodes yield an advance forecast warning window of 18 days, preventing antibiotic and IV fluid stockouts.
              </p>
            </div>

            <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-md">
              <div className="font-semibold text-blue-400 text-xs mb-1">
                Pediatric Acute Dehydration Clustering
              </div>
              <p className="text-slate-300 text-[11px]">
                South Africa’s rural primary clinic rehydration telemetry parameters are dynamically mapped onto coastal flood-prone talukas in Maharashtra, calculating accurate daily burn rates for ORS sachets and Ringer's Lactate bottles.
              </p>
            </div>

            <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-md">
              <div className="font-semibold text-amber-400 text-xs mb-1">
                Zero Patient Identifiers Disclosed
              </div>
              <p className="text-slate-300 text-[11px]">
                Complies with national digital personal data protection acts. Aggregator validates gradient updates using Byzantine-robust geometric median trimming, rejecting anomalous or corrupted parameter updates.
              </p>
            </div>
          </div>
        </div>

        {/* Right: Federated Round Execution Logs */}
        <div className="lg:col-span-7 rounded-lg border border-slate-800 bg-slate-900/60 p-4">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Layers className="h-4 w-4 text-blue-400" />
              <h3 className="text-sm font-semibold text-white tracking-tight">
                Consensus Aggregation History
              </h3>
            </div>
            <span className="text-xs text-slate-400">
              Immutable cryptographic ledger
            </span>
          </div>

          <div className="space-y-3">
            {roundLogs.map((log) => (
              <div
                key={log.roundNumber}
                className="p-3.5 bg-slate-950/70 border border-slate-800/80 rounded-lg text-xs"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2 pb-1.5 border-b border-slate-800/60">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white">
                      Round #{log.roundNumber}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {log.timestamp}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 font-mono text-[11px] tabular-nums">
                    <span className="text-slate-400">Loss: <strong className="text-emerald-400">{log.globalLoss}</strong></span>
                    <span className="text-slate-400">Acc: <strong className="text-white">{log.accuracy}%</strong></span>
                    <span className="text-slate-400">Updates: <strong className="text-slate-200">{log.gradientUpdatesProcessed.toLocaleString()}</strong></span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-300 leading-relaxed">
                  <span className="text-emerald-400 font-semibold">Consensus Insight: </span>
                  {log.topCrossBorderTransferInsight}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
