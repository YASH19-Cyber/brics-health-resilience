import React, { useState } from 'react';
import { HealthFacility, TransferManifest } from '../types';
import { ShieldAlert, CheckCircle2, AlertTriangle, Truck, Navigation, Thermometer, UserCheck, Bed } from 'lucide-react';

interface NetworkMapProps {
  facilities: HealthFacility[];
  transfers: TransferManifest[];
  onSelectFacility: (facility: HealthFacility) => void;
  selectedFacility: HealthFacility | null;
}

export const NetworkMap: React.FC<NetworkMapProps> = ({
  facilities,
  transfers,
  onSelectFacility,
  selectedFacility,
}) => {
  const [hoveredFacility, setHoveredFacility] = useState<HealthFacility | null>(null);
  const [filterTier, setFilterTier] = useState<string>('all');

  const filteredFacilities = facilities.filter(f => {
    if (filterTier === 'all') return true;
    return f.tier === filterTier;
  });

  const getStatusColor = (facility: HealthFacility) => {
    const hasCritical = facility.medicines.some(m => m.daysOfStockRemaining <= 3);
    const hasLow = facility.medicines.some(m => m.daysOfStockRemaining <= 7);
    const hasSurplus = facility.medicines.some(m => m.daysOfStockRemaining > 35);

    if (hasCritical || facility.powerColdChainStatus === 'battery_backup') return '#f43f5e'; // rose-500
    if (hasLow || facility.beds.occupancyRate >= 90) return '#f59e0b'; // amber-500
    if (hasSurplus) return '#3b82f6'; // blue-500
    return '#10b981'; // emerald-500
  };

  const getStatusLabel = (facility: HealthFacility) => {
    const hasCritical = facility.medicines.some(m => m.daysOfStockRemaining <= 3);
    const hasLow = facility.medicines.some(m => m.daysOfStockRemaining <= 7);
    const hasSurplus = facility.medicines.some(m => m.daysOfStockRemaining > 35);

    if (hasCritical) return 'Critical Stockout (<3d)';
    if (hasLow) return 'Low Stock (<7d)';
    if (hasSurplus) return 'Surplus Buffer Hub';
    return 'Nominal Supply';
  };

  // Active in-transit or authorized corridors
  const activeTransfers = transfers.filter(t => t.status === 'in_transit' || t.status === 'authorized');

  return (
    <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4 mb-6">
      {/* Map Control Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800/80">
        <div>
          <h2 className="text-sm font-semibold text-white tracking-tight">
            National PHC Geospatial Grid & Supply Corridors
          </h2>
          <p className="text-xs text-slate-400">
            Real-time telemetry from Primary Health Centres, Community Health referral hubs, and cold-chain transit routes
          </p>
        </div>

        {/* Tier Filter Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-md border border-slate-800">
          <button
            onClick={() => setFilterTier('all')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              filterTier === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Tiers ({facilities.length})
          </button>
          <button
            onClick={() => setFilterTier('PHC')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              filterTier === 'PHC' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            PHCs
          </button>
          <button
            onClick={() => setFilterTier('CHC')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              filterTier === 'CHC' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            CHCs
          </button>
          <button
            onClick={() => setFilterTier('District Hospital')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              filterTier === 'District Hospital' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            District Hubs
          </button>
        </div>
      </div>

      {/* SVG Map Canvas */}
      <div className="relative w-full h-[380px] bg-slate-950/80 rounded-lg border border-slate-800/80 overflow-hidden flex items-center justify-center">
        {/* District Boundary Background Lines */}
        <svg className="w-full h-full" viewBox="120 100 320 340">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255, 255, 255, 0.03)" strokeWidth="1" />
            </pattern>
            {/* Pulsing indicator animation */}
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          <rect x="100" y="80" width="360" height="380" fill="url(#grid)" />

          {/* District Boundary Polygons */}
          <path
            d="M 140 120 L 260 110 L 270 190 L 190 220 L 140 180 Z"
            fill="rgba(51, 65, 85, 0.12)"
            stroke="rgba(71, 85, 105, 0.3)"
            strokeWidth="1"
            strokeDasharray="4 2"
          />
          <text x="180" y="145" fill="rgba(148, 163, 184, 0.4)" fontSize="10" fontWeight="600">PUNE DISTRICT</text>

          <path
            d="M 210 200 L 350 180 L 370 280 L 290 340 L 220 280 Z"
            fill="rgba(51, 65, 85, 0.14)"
            stroke="rgba(71, 85, 105, 0.3)"
            strokeWidth="1"
            strokeDasharray="4 2"
          />
          <text x="280" y="240" fill="rgba(148, 163, 184, 0.4)" fontSize="10" fontWeight="600">SATARA DISTRICT</text>

          <path
            d="M 130 200 L 210 220 L 190 320 L 130 290 Z"
            fill="rgba(51, 65, 85, 0.1)"
            stroke="rgba(71, 85, 105, 0.3)"
            strokeWidth="1"
            strokeDasharray="4 2"
          />
          <text x="140" y="260" fill="rgba(148, 163, 184, 0.4)" fontSize="10" fontWeight="600">RAIGAD</text>

          <path
            d="M 250 330 L 380 320 L 390 420 L 250 420 Z"
            fill="rgba(51, 65, 85, 0.12)"
            stroke="rgba(71, 85, 105, 0.3)"
            strokeWidth="1"
            strokeDasharray="4 2"
          />
          <text x="290" y="375" fill="rgba(148, 163, 184, 0.4)" fontSize="10" fontWeight="600">KOLHAPUR DISTRICT</text>

          {/* Transfer Corridor Vectors */}
          {activeTransfers.map((transfer) => {
            const source = facilities.find(f => f.id === transfer.sourceFacilityId);
            const dest = facilities.find(f => f.id === transfer.destFacilityId);
            if (!source || !dest) return null;

            return (
              <g key={transfer.id}>
                {/* Connecting transit line */}
                <line
                  x1={source.coordinates.x}
                  y1={source.coordinates.y}
                  x2={dest.coordinates.x}
                  y2={dest.coordinates.y}
                  stroke="#10b981"
                  strokeWidth="2"
                  strokeDasharray="4 3"
                  className="animate-pulse"
                />
                {/* Midpoint transit badge */}
                <circle
                  cx={(source.coordinates.x + dest.coordinates.x) / 2}
                  cy={(source.coordinates.y + dest.coordinates.y) / 2}
                  r="5"
                  fill="#059669"
                />
              </g>
            );
          })}

          {/* Facility Nodes */}
          {filteredFacilities.map((facility) => {
            const color = getStatusColor(facility);
            const isSelected = selectedFacility?.id === facility.id;
            const isHovered = hoveredFacility?.id === facility.id;
            const radius = facility.tier === 'District Hospital' ? 10 : facility.tier === 'CHC' ? 8 : 6;

            return (
              <g
                key={facility.id}
                className="cursor-pointer transition-transform duration-200"
                onClick={() => onSelectFacility(facility)}
                onMouseEnter={() => setHoveredFacility(facility)}
                onMouseLeave={() => setHoveredFacility(null)}
              >
                {/* Ripple ring for critical facilities */}
                {(color === '#f43f5e' || isSelected) && (
                  <circle
                    cx={facility.coordinates.x}
                    cy={facility.coordinates.y}
                    r={radius + 8}
                    fill="none"
                    stroke={color}
                    strokeWidth="1.5"
                    opacity="0.4"
                    className="animate-ping"
                  />
                )}

                {/* Outer selection ring */}
                {isSelected && (
                  <circle
                    cx={facility.coordinates.x}
                    cy={facility.coordinates.y}
                    r={radius + 5}
                    fill="none"
                    stroke="#ffffff"
                    strokeWidth="2"
                  />
                )}

                {/* Main Node circle */}
                <circle
                  cx={facility.coordinates.x}
                  cy={facility.coordinates.y}
                  r={radius}
                  fill={color}
                  stroke="#0f172a"
                  strokeWidth="2"
                />

                {/* Facility Label */}
                <text
                  x={facility.coordinates.x + 10}
                  y={facility.coordinates.y + 4}
                  fill={isSelected ? '#ffffff' : '#cbd5e1'}
                  fontSize="9.5"
                  fontWeight={isSelected ? '700' : '500'}
                  className="select-none pointer-events-none drop-shadow"
                >
                  {facility.name.replace(' Primary Health Centre', '').replace(' Community Health Centre', '')}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Floating Quick Detail Popover on Hover */}
        {hoveredFacility && (
          <div 
            className="absolute z-20 pointer-events-none bg-slate-900/95 border border-slate-700/80 rounded-lg p-3 shadow-xl backdrop-blur-md text-xs w-64"
            style={{
              top: '16px',
              right: '16px',
            }}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-semibold text-white truncate">{hoveredFacility.name}</span>
              <span className="text-[10px] text-slate-400 font-mono">{hoveredFacility.tier}</span>
            </div>
            <div className="text-[11px] text-slate-400 mb-2">
              <span>{hoveredFacility.subDistrict}</span>
              <span aria-hidden="true" className="mx-1">·</span>
              <span>{hoveredFacility.district}</span>
            </div>

            <div className="space-y-1.5 pt-1 border-t border-slate-800 text-[11px]">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Stock Status:</span>
                <span className="font-medium text-slate-200">
                  {getStatusLabel(hoveredFacility)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Bed Occupancy:</span>
                <span className="font-mono tabular-nums text-slate-200">
                  {hoveredFacility.beds.occupied}/{hoveredFacility.beds.total} ({hoveredFacility.beds.occupancyRate}%)
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Doctors on Duty:</span>
                <span className="font-mono tabular-nums text-slate-200">
                  {hoveredFacility.personnel.medicalOfficers.present}/{hoveredFacility.personnel.medicalOfficers.sanctioned} present
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Map Legend */}
        <div className="absolute bottom-3 left-3 bg-slate-950/90 border border-slate-800/80 rounded px-2.5 py-1.5 flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-rose-500" />
            <span>Critical Deficit (&lt;3d)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-amber-500" />
            <span>Low Stock / Strained</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            <span>Nominal Supply</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-blue-500" />
            <span>Surplus Buffer Hub</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-4 border-b-2 border-dashed border-emerald-400 inline-block" />
            <span>Active Dispatch Route</span>
          </div>
        </div>
      </div>
    </div>
  );
};
