import React, { useState } from 'react';
import { HealthFacility } from '../types';
import { Search, AlertCircle, CheckCircle2, ChevronRight, Filter, ShieldAlert } from 'lucide-react';

interface FacilityInventoryTableProps {
  facilities: HealthFacility[];
  onSelectFacility: (facility: HealthFacility) => void;
  selectedFacility: HealthFacility | null;
}

export const FacilityInventoryTable: React.FC<FacilityInventoryTableProps> = ({
  facilities,
  onSelectFacility,
  selectedFacility,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'critical' | 'low' | 'nominal' | 'surplus'>('all');

  // Extract unique districts
  const districts = Array.from(new Set(facilities.map(f => f.district)));

  // Filter facilities
  const filteredFacilities = facilities.filter(f => {
    const matchesSearch = f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          f.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          f.subDistrict.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDistrict = selectedDistrict === 'all' || f.district === selectedDistrict;

    if (!matchesSearch || !matchesDistrict) return false;

    if (statusFilter === 'all') return true;
    if (statusFilter === 'critical') return f.medicines.some(m => m.daysOfStockRemaining <= 3);
    if (statusFilter === 'low') return f.medicines.some(m => m.daysOfStockRemaining > 3 && m.daysOfStockRemaining <= 7);
    if (statusFilter === 'surplus') return f.medicines.some(m => m.daysOfStockRemaining > 35);
    if (statusFilter === 'nominal') {
      const hasCrit = f.medicines.some(m => m.daysOfStockRemaining <= 3);
      const hasLow = f.medicines.some(m => m.daysOfStockRemaining <= 7);
      return !hasCrit && !hasLow;
    }
    return true;
  });

  return (
    <div className="rounded-lg border border-slate-800 bg-slate-900/60 overflow-hidden">
      {/* Header & Filter Controls */}
      <div className="p-4 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-white tracking-tight">
            Primary Health Centre Telemetry & Stock Registry
          </h2>
          <p className="text-xs text-slate-400">
            Real-time medicine burn rates, bed utilization, and clinical personnel attendance
          </p>
        </div>

        {/* Search & Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search PHC or Taluka..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-48 pl-8 pr-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* District Dropdown */}
          <select
            value={selectedDistrict}
            onChange={(e) => setSelectedDistrict(e.target.value)}
            className="text-xs bg-slate-950 border border-slate-800 rounded-md px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-emerald-500"
          >
            <option value="all">All Districts</option>
            {districts.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>

          {/* Status Filter Segmented Buttons */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-md border border-slate-800">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-2 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                statusFilter === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setStatusFilter('critical')}
              className={`px-2 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                statusFilter === 'critical' ? 'bg-rose-950/80 text-rose-300 border border-rose-800/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Critical (&lt;3d)
            </button>
            <button
              onClick={() => setStatusFilter('low')}
              className={`px-2 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                statusFilter === 'low' ? 'bg-amber-950/80 text-amber-300 border border-amber-800/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Low (&lt;7d)
            </button>
            <button
              onClick={() => setStatusFilter('surplus')}
              className={`px-2 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                statusFilter === 'surplus' ? 'bg-blue-950/80 text-blue-300 border border-blue-800/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Surplus Hubs
            </button>
          </div>
        </div>
      </div>

      {/* High-Density Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-medium">
            <tr>
              <th className="py-2.5 px-4 font-medium">Facility / District</th>
              <th className="py-2.5 px-3 font-medium">Tier</th>
              <th className="py-2.5 px-3 font-medium">Daily Footfall</th>
              <th className="py-2.5 px-3 font-medium">Lowest Stock Remaining</th>
              <th className="py-2.5 px-3 font-medium text-right">Bed Occupancy</th>
              <th className="py-2.5 px-3 font-medium text-right">Doctors / Nurses</th>
              <th className="py-2.5 px-3 font-medium">Cold Chain</th>
              <th className="py-2.5 px-4 font-medium text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredFacilities.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-400">
                  No health facilities match the selected filter criteria.
                </td>
              </tr>
            ) : (
              filteredFacilities.map((facility) => {
                // Find lowest stock item
                const sortedMeds = [...facility.medicines].sort((a, b) => a.daysOfStockRemaining - b.daysOfStockRemaining);
                const lowestMed = sortedMeds[0];
                const isSelected = selectedFacility?.id === facility.id;

                const hasCritical = lowestMed && lowestMed.daysOfStockRemaining <= 3;
                const hasLow = lowestMed && lowestMed.daysOfStockRemaining > 3 && lowestMed.daysOfStockRemaining <= 7;
                const isSurplus = lowestMed && lowestMed.daysOfStockRemaining > 35;

                return (
                  <tr
                    key={facility.id}
                    onClick={() => onSelectFacility(facility)}
                    className={`cursor-pointer transition-colors hover:bg-slate-800/50 ${
                      isSelected ? 'bg-slate-800/80' : ''
                    }`}
                  >
                    {/* Facility & District */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-200">
                        {facility.name}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <span>{facility.code}</span>
                        <span aria-hidden="true">·</span>
                        <span>{facility.district}</span>
                        <span aria-hidden="true">·</span>
                        <span>Pop. {facility.catchmentPopulation.toLocaleString()}</span>
                      </div>
                    </td>

                    {/* Tier */}
                    <td className="py-3 px-3 text-slate-300 font-mono">
                      {facility.tier}
                    </td>

                    {/* Today Footfall */}
                    <td className="py-3 px-3">
                      <div className="font-mono tabular-nums font-medium text-slate-200">
                        {facility.todayFootfall} patients
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Avg: {facility.avgDailyFootfall} · Surge {facility.feverClinicSurgeRate}%
                      </div>
                    </td>

                    {/* Lowest Stock Remaining */}
                    <td className="py-3 px-3">
                      {lowestMed ? (
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`font-mono tabular-nums font-semibold ${
                                hasCritical ? 'text-rose-400' : hasLow ? 'text-amber-400' : isSurplus ? 'text-blue-400' : 'text-emerald-400'
                              }`}
                            >
                              {lowestMed.daysOfStockRemaining} days
                            </span>
                            <span className="text-[11px] text-slate-400 truncate max-w-[130px]" title={lowestMed.name}>
                              ({lowestMed.name.split(' ')[0]})
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {hasCritical ? 'Critical Stockout Risk' : hasLow ? 'Depletion Warning' : isSurplus ? 'Surplus Reserve Hub' : 'Adequate Supply'}
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-500">No data</span>
                      )}
                    </td>

                    {/* Bed Occupancy */}
                    <td className="py-3 px-3 text-right">
                      <div className="font-mono tabular-nums font-semibold text-slate-200">
                        {facility.beds.occupancyRate}%
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono tabular-nums">
                        {facility.beds.occupied} / {facility.beds.total} beds
                      </div>
                    </td>

                    {/* Medical Personnel */}
                    <td className="py-3 px-3 text-right">
                      <div className="font-mono tabular-nums font-medium text-slate-200">
                        {facility.personnel.medicalOfficers.present} Dr · {facility.personnel.staffNurses.present} Nurse
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {facility.personnel.shiftStatus}
                      </div>
                    </td>

                    {/* Cold Chain Status */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`h-2 w-2 rounded-full ${
                            facility.powerColdChainStatus === 'nominal'
                              ? 'bg-emerald-400'
                              : facility.powerColdChainStatus === 'battery_backup'
                              ? 'bg-amber-400 animate-pulse'
                              : 'bg-rose-500 animate-ping'
                          }`}
                        />
                        <span className="text-slate-300 capitalize text-[11px]">
                          {facility.powerColdChainStatus.replace('_', ' ')}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        2°C–8°C Verified
                      </div>
                    </td>

                    {/* Action */}
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectFacility(facility);
                        }}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                      >
                        <span>Inspect</span>
                        <ChevronRight className="h-3 w-3" />
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
