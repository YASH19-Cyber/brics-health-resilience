import React, { useState } from 'react';
import { CrisisDirectiveResponse, EmergencyScenario } from '../types';
import { Sparkles, X, CheckCircle2, AlertTriangle, Shield, Globe, RefreshCw, Send } from 'lucide-react';

interface AiDirectiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  directive: CrisisDirectiveResponse | null;
  isLoading: boolean;
  onRegenerate: () => void;
  activeScenario: EmergencyScenario;
  deficitCount: number;
}

export const AiDirectiveModal: React.FC<AiDirectiveModalProps> = ({
  isOpen,
  onClose,
  directive,
  isLoading,
  onRegenerate,
  activeScenario,
  deficitCount,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl p-6 relative">
        {/* Modal Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Sparkles className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                National Health Logistics Command Directive
              </h2>
              <p className="text-xs text-slate-400">
                AI clinical triage & cross-district redistribution reasoning (Gemini 3.8 Flash)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content State */}
        {isLoading ? (
          <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
            <RefreshCw className="h-8 w-8 text-emerald-400 animate-spin" />
            <div className="text-sm font-semibold text-slate-200">
              Formulating Clinical Logistics Directive...
            </div>
            <div className="text-xs text-slate-400 max-w-md">
              Evaluating current PHC burn rates, cold-chain capacity, and cross-BRICS transfer learning parameters for {activeScenario.replace('_', ' ')}.
            </div>
          </div>
        ) : directive ? (
          <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
            {/* Executive Summary */}
            <div className="p-3.5 bg-slate-950/80 rounded-lg border border-slate-800">
              <div className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider mb-1">
                Executive Operational Appraisal
              </div>
              <p className="text-xs text-slate-200 leading-relaxed">
                {directive.executiveSummary}
              </p>
            </div>

            {/* Clinical Priorities */}
            <div className="p-3.5 bg-slate-950/80 rounded-lg border border-slate-800">
              <div className="text-[11px] font-semibold text-blue-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Shield className="h-3.5 w-3.5" />
                <span>Primary Care Clinical Priorities</span>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {directive.clinicalPriorities.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold shrink-0">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Logistical Action Plan */}
            <div className="p-3.5 bg-slate-950/80 rounded-lg border border-slate-800">
              <div className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Send className="h-3.5 w-3.5" />
                <span>Inter-District Redistribution & Cold-Chain Protocol</span>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {directive.logisticalActionPlan.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-amber-400 font-bold shrink-0">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* BRICS Shared Predictive Modeling Note */}
            <div className="p-3.5 bg-emerald-950/20 rounded-lg border border-emerald-800/40">
              <div className="text-[11px] font-semibold text-emerald-300 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                <Globe className="h-3.5 w-3.5" />
                <span>BRICS Federated Consensus Synergy</span>
              </div>
              <p className="text-xs text-emerald-200/90 leading-relaxed">
                {directive.bricsTransferLearningNote}
              </p>
            </div>
          </div>
        ) : null}

        {/* Modal Footer Actions */}
        <div className="pt-4 mt-4 border-t border-slate-800 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            Targeting {deficitCount} deficit health centres
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onRegenerate}
              disabled={isLoading}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors cursor-pointer"
            >
              <RefreshCw className={`h-3 w-3 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Regenerate Analysis</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-md transition-colors cursor-pointer shadow-sm"
            >
              Acknowledge & Apply
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
