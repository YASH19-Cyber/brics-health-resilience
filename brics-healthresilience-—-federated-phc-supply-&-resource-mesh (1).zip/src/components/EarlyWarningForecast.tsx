import React, { useState } from 'react';
import { HealthFacility, EmergencyScenario, EarlyWarningAlert } from '../types';
import { AlertTriangle, TrendingUp, AlertCircle, ShieldAlert, Zap, Clock, ChevronRight, Activity } from 'lucide-react';

interface EarlyWarningForecastProps {
  facilities: HealthFacility[];
  activeScenario: EmergencyScenario;
  onScenarioChange: (scenario: EmergencyScenario) => void;
  onSelectFacility: (facility: HealthFacility) => void;
}

export const EarlyWarningForecast: React.FC<EarlyWarningForecastProps> = ({
  facilities,
  activeScenario,
  onScenarioChange,
  onSelectFacility,
}) => {
  const [selectedMedicineName, setSelectedMedicineName] = useState<string>('Amoxicillin + Clavulanic Acid 625mg');
  const [forecastHorizonDays, setForecastHorizonDays] = useState<7 | 14 | 30>(14);

  // Compute dynamic early warnings from current facilities
  const alerts: EarlyWarningAlert[] = [];

  facilities.forEach(facility => {
    // Check medicine stockouts
    facility.medicines.forEach(m => {
      if (m.daysOfStockRemaining <= 3) {
        alerts.push({
          id: `alert-stock-${facility.id}-${m.id}`,
          facilityId: facility.id,
          facilityName: facility.name,
          district: facility.district,
          severity: 'critical',
          category: 'Medicine Stockout',
          headline: `Imminent Stockout: ${m.name}`,
          details: `Current stock: ${m.currentStock} ${m.unit} at daily burn rate of ${m.dailyBurnRate} ${m.unit}/day. Complete depletion projected within ${Math.round(m.daysOfStockRemaining * 24)} hours.`,
          projectedCrisisTimeframe: `${m.daysOfStockRemaining} days (${Math.round(m.daysOfStockRemaining * 24)}h)`,
          impactedCohort: m.category === 'Maternal Health' ? 'Maternity & postpartum hemorrhage cases' : m.category === 'Antimalarials' ? 'Fever clinic triage & pediatric malaria' : 'Primary OPD infections',
          suggestedAction: 'Authorize automated inter-district transfer from nearest surplus hub.',
          timestamp: 'Live alert',
        });
      } else if (m.daysOfStockRemaining <= 7) {
        alerts.push({
          id: `alert-stock-${facility.id}-${m.id}`,
          facilityId: facility.id,
          facilityName: facility.name,
          district: facility.district,
          severity: 'warning',
          category: 'Medicine Stockout',
          headline: `Low Stock Reserve: ${m.name}`,
          details: `Buffer below safe operational threshold (${m.safetyThresholdDays} days). Current buffer: ${m.daysOfStockRemaining} days.`,
          projectedCrisisTimeframe: `${m.daysOfStockRemaining} days`,
          impactedCohort: 'General primary care consultations',
          suggestedAction: 'Queue priority batch replenishment in next distribution cycle.',
          timestamp: 'Surveillance notice',
        });
      }
    });

    // Check bed saturation
    if (facility.beds.occupancyRate >= 85) {
      alerts.push({
        id: `alert-bed-${facility.id}`,
        facilityId: facility.id,
        facilityName: facility.name,
        district: facility.district,
        severity: facility.beds.occupancyRate >= 100 ? 'critical' : 'warning',
        category: 'Bed Saturation',
        headline: `High Bed Occupancy: ${facility.beds.occupancyRate}% (${facility.beds.occupied}/${facility.beds.total} Beds)`,
        details: `Stabilization and maternal delivery beds are at or exceeding nominal capacity.`,
        projectedCrisisTimeframe: 'Immediate',
        impactedCohort: 'Emergency admissions & overnight observation',
        suggestedAction: 'Divert non-emergency admissions to nearest Community Health Centre.',
        timestamp: 'Real-time telemetry',
      });
    }

    // Check cold chain failure
    if (facility.powerColdChainStatus === 'battery_backup') {
      alerts.push({
        id: `alert-pwr-${facility.id}`,
        facilityId: facility.id,
        facilityName: facility.name,
        district: facility.district,
        severity: 'warning',
        category: 'Cold-Chain Failure',
        headline: 'Cold Chain Running on Inverter/Battery Backup',
        details: 'Grid power disconnected. Temperature logging at safe 2°C–8°C limit, but battery runtime estimated at 6.5 hours.',
        projectedCrisisTimeframe: '6.5 hours backup remaining',
        impactedCohort: 'Vaccines, insulin, and oxytocin stocks',
        suggestedAction: 'Dispatch mobile generator unit or prepare cold-box transfer.',
        timestamp: 'Hardware sensor trigger',
      });
    }
  });

  // Sort alerts: critical first
  alerts.sort((a, b) => (a.severity === 'critical' ? -1 : 1));

  // Synthesize 14-day projection data for the selected medicine
  const sampleFacility = facilities[0];
  const med = sampleFacility.medicines.find(m => m.name === selectedMedicineName) || sampleFacility.medicines[0];
  
  const currentStock = med?.currentStock || 500;
  const burnRate = med?.dailyBurnRate || 40;
  const surgeMultiplier = activeScenario === 'monsoon_dengue' ? 1.8 : activeScenario === 'flood_cholera' ? 2.2 : activeScenario === 'respiratory_surge' ? 1.6 : 1.0;
  const effectiveBurnRate = burnRate * surgeMultiplier;

  // Generate 14-day data points
  const forecastDays = Array.from({ length: forecastHorizonDays }, (_, i) => {
    const day = i + 1;
    const projectedRemaining = Math.max(0, Math.round(currentStock - (effectiveBurnRate * day)));
    const baselineRemaining = Math.max(0, Math.round(currentStock - (burnRate * day)));
    const threshold = Math.round(burnRate * med.safetyThresholdDays);

    return {
      day: `Day +${day}`,
      projectedRemaining,
      baselineRemaining,
      threshold,
      isStockout: projectedRemaining === 0,
    };
  });

  return (
    <div className="space-y-6">
      {/* Top Banner: Emergency Scenario Trigger */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2">
              <Activity className="h-4 w-4 text-emerald-400" />
              <span>Epidemiological Crisis Simulator & Predictive Forecasting</span>
            </h2>
            <p className="text-xs text-slate-400">
              Test PHC resilience under sudden multi-district health emergencies and vector-borne shocks
            </p>
          </div>

          <div className="text-xs text-slate-400">
            Active Scenario: <span className="font-semibold text-white capitalize">{activeScenario.replace('_', ' ')}</span>
          </div>
        </div>

        {/* Scenario Selection Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          <button
            onClick={() => onScenarioChange('baseline')}
            className={`p-2.5 rounded-md border text-left transition-all ${
              activeScenario === 'baseline'
                ? 'bg-slate-800 border-slate-600 text-white'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
            }`}
          >
            <div className="text-xs font-semibold text-slate-200">Baseline Health</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Normal seasonal footfall</div>
          </button>

          <button
            onClick={() => onScenarioChange('monsoon_dengue')}
            className={`p-2.5 rounded-md border text-left transition-all ${
              activeScenario === 'monsoon_dengue'
                ? 'bg-rose-950/60 border-rose-600/80 text-white'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
            }`}
          >
            <div className="text-xs font-semibold text-rose-300">Monsoon Dengue</div>
            <div className="text-[10px] text-slate-400 mt-0.5">+180% ACT & IV burn rate</div>
          </button>

          <button
            onClick={() => onScenarioChange('flood_cholera')}
            className={`p-2.5 rounded-md border text-left transition-all ${
              activeScenario === 'flood_cholera'
                ? 'bg-blue-950/60 border-blue-600/80 text-white'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
            }`}
          >
            <div className="text-xs font-semibold text-blue-300">Flood & Cholera</div>
            <div className="text-[10px] text-slate-400 mt-0.5">+240% ORS & RL fluids</div>
          </button>

          <button
            onClick={() => onScenarioChange('respiratory_surge')}
            className={`p-2.5 rounded-md border text-left transition-all ${
              activeScenario === 'respiratory_surge'
                ? 'bg-amber-950/60 border-amber-600/80 text-white'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
            }`}
          >
            <div className="text-xs font-semibold text-amber-300">Respiratory Wave</div>
            <div className="text-[10px] text-slate-400 mt-0.5">+160% Antibiotic surge</div>
          </button>

          <button
            onClick={() => onScenarioChange('cold_chain_failure')}
            className={`p-2.5 rounded-md border text-left transition-all ${
              activeScenario === 'cold_chain_failure'
                ? 'bg-purple-950/60 border-purple-600/80 text-white'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
            }`}
          >
            <div className="text-xs font-semibold text-purple-300">Cold Chain Grid Cut</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Vaccine spoilage hazard</div>
          </button>
        </div>
      </div>

      {/* Main Grid: Forecast Graph (Left) + Early Warning Alerts (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Predictive Demand Graph */}
        <div className="lg:col-span-7 rounded-lg border border-slate-800 bg-slate-900/60 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800/80">
            <div>
              <h3 className="text-sm font-semibold text-white tracking-tight">
                Predictive Depletion Trajectory
              </h3>
              <p className="text-xs text-slate-400">
                Depletion projection for {sampleFacility.name}
              </p>
            </div>

            {/* Medicine Selector & Horizon Tabs */}
            <div className="flex items-center gap-2">
              <select
                value={selectedMedicineName}
                onChange={(e) => setSelectedMedicineName(e.target.value)}
                className="text-xs bg-slate-950 border border-slate-800 rounded-md px-2.5 py-1 text-slate-200 focus:outline-none focus:border-emerald-500 max-w-[200px] truncate"
              >
                {sampleFacility.medicines.map(m => (
                  <option key={m.name} value={m.name}>{m.name}</option>
                ))}
              </select>

              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-md border border-slate-800">
                <button
                  onClick={() => setForecastHorizonDays(7)}
                  className={`px-2 py-0.5 text-xs font-medium rounded ${
                    forecastHorizonDays === 7 ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  7d
                </button>
                <button
                  onClick={() => setForecastHorizonDays(14)}
                  className={`px-2 py-0.5 text-xs font-medium rounded ${
                    forecastHorizonDays === 14 ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  14d
                </button>
                <button
                  onClick={() => setForecastHorizonDays(30)}
                  className={`px-2 py-0.5 text-xs font-medium rounded ${
                    forecastHorizonDays === 30 ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  30d
                </button>
              </div>
            </div>
          </div>

          {/* SVG Line / Bar Forecast Visualization */}
          <div className="relative w-full h-[260px] bg-slate-950/70 rounded-lg p-3 border border-slate-800/80 flex flex-col justify-between">
            {/* SVG Depletion Curve */}
            <svg className="w-full h-[200px]" viewBox="0 0 500 180" preserveAspectRatio="none">
              <defs>
                <linearGradient id="surgeArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Grid lines */}
              <line x1="0" y1="40" x2="500" y2="40" stroke="rgba(255,255,255,0.05)" strokeDasharray="3 3" />
              <line x1="0" y1="90" x2="500" y2="90" stroke="rgba(255,255,255,0.05)" strokeDasharray="3 3" />
              <line x1="0" y1="140" x2="500" y2="140" stroke="rgba(255,255,255,0.05)" strokeDasharray="3 3" />

              {/* Threshold line (dashed amber) */}
              <line x1="0" y1="70" x2="500" y2="70" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="4 4" />
              <text x="10" y="65" fill="#f59e0b" fontSize="9" fontWeight="600">Safety Buffer Baseline (14 Days)</text>

              {/* Baseline Trend Curve (Grey/Blue) */}
              <path
                d={forecastDays.reduce((acc, pt, idx) => {
                  const x = (idx / (forecastDays.length - 1)) * 480 + 10;
                  const maxStock = currentStock || 1;
                  const y = 160 - (pt.baselineRemaining / maxStock) * 130;
                  return `${acc} ${idx === 0 ? 'M' : 'L'} ${x} ${Math.min(160, Math.max(20, y))}`;
                }, '')}
                fill="none"
                stroke="#64748b"
                strokeWidth="2"
                strokeDasharray="3 3"
              />

              {/* Surge Epidemic Depletion Curve (Red) */}
              <path
                d={forecastDays.reduce((acc, pt, idx) => {
                  const x = (idx / (forecastDays.length - 1)) * 480 + 10;
                  const maxStock = currentStock || 1;
                  const y = 160 - (pt.projectedRemaining / maxStock) * 130;
                  return `${acc} ${idx === 0 ? 'M' : 'L'} ${x} ${Math.min(160, Math.max(20, y))}`;
                }, '')}
                fill="none"
                stroke="#f43f5e"
                strokeWidth="2.5"
              />

              {/* Stockout Intersection Dot */}
              {forecastDays.findIndex(d => d.projectedRemaining === 0) !== -1 && (
                <circle
                  cx={(forecastDays.findIndex(d => d.projectedRemaining === 0) / (forecastDays.length - 1)) * 480 + 10}
                  cy="160"
                  r="6"
                  fill="#f43f5e"
                  stroke="#ffffff"
                  strokeWidth="2"
                  className="animate-ping"
                />
              )}
            </svg>

            {/* X-Axis Labels */}
            <div className="flex justify-between text-[10px] text-slate-500 font-mono pt-1 border-t border-slate-800">
              <span>Today (Stock: {currentStock})</span>
              <span>Day +{Math.round(forecastHorizonDays / 2)}</span>
              <span>Day +{forecastHorizonDays} (Projected: {forecastDays[forecastDays.length - 1]?.projectedRemaining})</span>
            </div>
          </div>

          {/* Graph Legend & Insights */}
          <div className="mt-3 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <span className="h-0.5 w-4 bg-rose-500 inline-block" />
                <span className="text-slate-300">Surge Depletion ({effectiveBurnRate}/day)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-0.5 w-4 border-b border-dashed border-slate-400 inline-block" />
                <span>Baseline ({burnRate}/day)</span>
              </div>
            </div>

            <div className="text-[11px] font-mono text-rose-400">
              Stockout Projected: {med?.daysOfStockRemaining} days without replenishment
            </div>
          </div>
        </div>

        {/* Right Column: Early Warning System Alerts */}
        <div className="lg:col-span-5 rounded-lg border border-slate-800 bg-slate-900/60 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <ShieldAlert className="h-4 w-4 text-rose-400" />
                <h3 className="text-sm font-semibold text-white tracking-tight">
                  National Early Warning Feed ({alerts.length})
                </h3>
              </div>
              <span className="text-xs text-slate-400">
                Automated triage
              </span>
            </div>

            <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
              {alerts.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  No active stockout or capacity alerts in the current surveillance window.
                </div>
              ) : (
                alerts.slice(0, 5).map(alert => (
                  <div
                    key={alert.id}
                    onClick={() => {
                      const fac = facilities.find(f => f.id === alert.facilityId);
                      if (fac) onSelectFacility(fac);
                    }}
                    className={`p-3 rounded-lg border transition-all cursor-pointer ${
                      alert.severity === 'critical'
                        ? 'bg-rose-950/30 border-rose-800/50 hover:border-rose-600'
                        : 'bg-amber-950/20 border-amber-800/40 hover:border-amber-600'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="font-semibold text-xs text-white">
                        {alert.headline}
                      </div>
                      <span
                        className={`text-[10px] font-mono font-medium ${
                          alert.severity === 'critical' ? 'text-rose-400' : 'text-amber-400'
                        }`}
                      >
                        {alert.projectedCrisisTimeframe}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-300 mb-2 leading-relaxed">
                      {alert.details}
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800/60">
                      <span>{alert.facilityName} · {alert.district}</span>
                      <span className="text-emerald-400 font-medium">Inspect →</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Federated Consensus Alert Engine</span>
            <span>Refreshed 24s ago</span>
          </div>
        </div>
      </div>
    </div>
  );
};
