import { HealthFacility, TransferManifest, TransferManifestItem, StockHealthStatus } from '../types';

/**
 * Calculates geographic distance in km between two coordinate pairs
 */
export function calculateDistanceKm(c1: { lat: number; lng: number }, c2: { lat: number; lng: number }): number {
  const R = 6371; // Earth radius in km
  const dLat = (c2.lat - c1.lat) * (Math.PI / 180);
  const dLng = (c2.lng - c1.lng) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(c1.lat * (Math.PI / 180)) * Math.cos(c2.lat * (Math.PI / 180)) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

/**
 * Core Automated Cross-District Redistribution Algorithm
 * Identifies deficit facilities (<5 days of stock) and matches with optimal surplus hubs
 */
export function generateAutomatedRedistribution(facilities: HealthFacility[]): TransferManifest[] {
  const manifests: TransferManifest[] = [];
  const facilityMap = new Map(facilities.map(f => [f.id, JSON.parse(JSON.stringify(f)) as HealthFacility]));

  // Find facilities with critical or low stock
  facilities.forEach((deficitFacility) => {
    const deficitItems = deficitFacility.medicines.filter(m => m.daysOfStockRemaining <= 5);

    deficitItems.forEach((defItem) => {
      // Look for a potential donor facility that has surplus and is geographically feasible
      let bestDonor: HealthFacility | null = null;
      let minDistance = Infinity;
      let transferQty = 0;

      facilities.forEach((candidateDonor) => {
        if (candidateDonor.id === deficitFacility.id) return;

        const donorMed = candidateDonor.medicines.find(m => m.name === defItem.name);
        if (!donorMed) return;

        // Ensure candidate donor has surplus (> 25 days stock)
        // and would retain at least 18 days of stock after donating
        const minRetainedStock = donorMed.dailyBurnRate * 18;
        const availableSurplus = donorMed.currentStock - minRetainedStock;

        if (availableSurplus > 50) {
          const dist = calculateDistanceKm(candidateDonor.coordinates, deficitFacility.coordinates);
          if (dist < minDistance) {
            minDistance = dist;
            bestDonor = candidateDonor;
            // Target bringing deficit facility to at least 14 days of safety stock
            const neededQty = Math.ceil((14 - defItem.daysOfStockRemaining) * defItem.dailyBurnRate);
            transferQty = Math.min(availableSurplus, neededQty);
          }
        }
      });

      if (bestDonor && transferQty > 0) {
        // Check if an existing manifest between these two facilities already exists
        const existingManifest = manifests.find(
          m => m.sourceFacilityId === (bestDonor as HealthFacility).id && m.destFacilityId === deficitFacility.id
        );

        const transferItem: TransferManifestItem = {
          medicineId: defItem.id,
          medicineName: defItem.name,
          quantity: transferQty,
          unit: defItem.unit,
          requiresColdChain: defItem.requiresColdChain,
        };

        if (existingManifest) {
          if (!existingManifest.items.some(i => i.medicineName === defItem.name)) {
            existingManifest.items.push(transferItem);
            if (defItem.requiresColdChain) {
              existingManifest.vehicleType = 'Refrigerated Cold-Chain Van';
            }
          }
        } else {
          const donorFac = bestDonor as HealthFacility;
          const travelMinutes = Math.round(minDistance * 1.8 + 20); // Average rural road transit speed
          const hoursToStockout = Math.max(0.5, Math.round(defItem.daysOfStockRemaining * 24 * 10) / 10);

          manifests.push({
            id: `TRF-${donorFac.district.slice(0, 3).toUpperCase()}-${deficitFacility.district.slice(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`,
            sourceFacilityId: donorFac.id,
            sourceFacilityName: donorFac.name,
            sourceDistrict: donorFac.district,
            destFacilityId: deficitFacility.id,
            destFacilityName: deficitFacility.name,
            destDistrict: deficitFacility.district,
            items: [transferItem],
            distanceKm: minDistance,
            estimatedTransitMinutes: travelMinutes,
            vehicleType: defItem.requiresColdChain ? 'Refrigerated Cold-Chain Van' : 'Emergency Medical Courier',
            courierName: 'MH-EMS FastTrack Logistics Unit',
            driverContact: '+91 98230 ' + Math.floor(10000 + Math.random() * 90000),
            status: 'suggested',
            urgency: defItem.daysOfStockRemaining <= 2 ? 'critical' : 'high',
            projectedStockoutHours: hoursToStockout,
            createdAt: 'Just now',
          });
        }
      }
    });
  });

  return manifests;
}

/**
 * Applies a delivered manifest to update inventory in real-time
 */
export function applyTransferDelivery(facilities: HealthFacility[], manifest: TransferManifest): HealthFacility[] {
  return facilities.map(facility => {
    if (facility.id === manifest.sourceFacilityId) {
      // Deduct items from source
      const updatedMeds = facility.medicines.map(m => {
        const itemTransferred = manifest.items.find(i => i.medicineName === m.name);
        if (itemTransferred) {
          const newStock = Math.max(0, m.currentStock - itemTransferred.quantity);
          const daysRemaining = Math.round((newStock / m.dailyBurnRate) * 10) / 10;
          const status: StockHealthStatus = daysRemaining <= 3 ? 'critical' : daysRemaining <= 7 ? 'low' : daysRemaining > 30 ? 'surplus' : 'nominal';
          return {
            ...m,
            currentStock: newStock,
            daysOfStockRemaining: daysRemaining,
            status,
          };
        }
        return m;
      });
      return { ...facility, medicines: updatedMeds };
    }

    if (facility.id === manifest.destFacilityId) {
      // Add items to destination
      const updatedMeds = facility.medicines.map(m => {
        const itemTransferred = manifest.items.find(i => i.medicineName === m.name);
        if (itemTransferred) {
          const newStock = m.currentStock + itemTransferred.quantity;
          const daysRemaining = Math.round((newStock / m.dailyBurnRate) * 10) / 10;
          const status: StockHealthStatus = daysRemaining <= 3 ? 'critical' : daysRemaining <= 7 ? 'low' : daysRemaining > 30 ? 'surplus' : 'nominal';
          return {
            ...m,
            currentStock: newStock,
            daysOfStockRemaining: daysRemaining,
            status,
          };
        }
        return m;
      });
      return {
        ...facility,
        medicines: updatedMeds,
        stockoutRiskScore: Math.max(10, facility.stockoutRiskScore - 45),
      };
    }

    return facility;
  });
}
