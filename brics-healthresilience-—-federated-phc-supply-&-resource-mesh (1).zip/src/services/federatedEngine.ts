import { FederatedParticipantNode, FederatedRoundLog } from '../types';

export interface FederatedConsensusState {
  currentRound: number;
  globalModelVersion: string;
  globalLoss: number;
  globalAccuracy: number;
  privacyEpsilonBudget: number; // e.g. 0.82
  nodes: FederatedParticipantNode[];
  roundLogs: FederatedRoundLog[];
  isAggregating: boolean;
  aggregationProgress: number; // 0 to 100
}

export function executeFederatedRound(
  currentNodes: FederatedParticipantNode[],
  currentLogs: FederatedRoundLog[],
  roundNumber: number
): {
  updatedNodes: FederatedParticipantNode[];
  newRoundLog: FederatedRoundLog;
  newGlobalLoss: number;
  newAccuracy: number;
} {
  // Simulate convergence with natural diminishing returns
  const prevLoss = currentLogs[0]?.globalLoss || 0.150;
  const prevAcc = currentLogs[0]?.accuracy || 94.0;

  const lossReduction = Math.max(0.003, Math.min(0.009, (prevLoss * 0.05)));
  const newGlobalLoss = Math.round((prevLoss - lossReduction) * 1000) / 1000;
  const newAccuracy = Math.min(98.5, Math.round((prevAcc + (0.3 + Math.random() * 0.4)) * 10) / 10);

  const insights = [
    'Sub-Saharan Africa pediatric dehydration curve updates integrated with Coastal India PHCs, reducing fluid stockout alerts by 28%.',
    'Brazilian SUS monsoon arbovirus (dengue/chikungunya) gradient weights aligned with Maharashtra rural health corridors.',
    'Sino-Indian high-density fever clinic footfall predictive weights synchronized with 99.4% privacy budget compliance.',
    'Russian sub-zero cold-chain temperature telemetry parameters improved vaccine thermal excursion alerts across high-altitude clinics.',
    'Ethiopian community health worker (HEW) field distribution weights improved rural outpost outreach forecasting by +16.2%.'
  ];

  const randomInsight = insights[(roundNumber - 42 + insights.length) % insights.length];

  const updatedNodes = currentNodes.map(node => {
    const nodeLossDelta = (Math.random() * 0.008) + 0.002;
    const newLoss = Math.max(0.09, Math.round((node.currentLoss - nodeLossDelta) * 1000) / 1000);
    const newAcc = Math.min(98.8, Math.round((node.accuracyScore + (Math.random() * 0.4 + 0.1)) * 10) / 10);
    const newEpsilon = Math.round((node.privacyEpsilon + 0.01) * 100) / 100;

    return {
      ...node,
      currentLoss: newLoss,
      accuracyScore: newAcc,
      privacyEpsilon: newEpsilon,
      modelWeightsVersion: `v4.13.${roundNumber}-${node.country.slice(0, 3).toUpperCase()}`,
      lastRoundContribution: `Round #${roundNumber} verified & merged`,
      status: 'synced' as const,
    };
  });

  const newRoundLog: FederatedRoundLog = {
    roundNumber,
    timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
    globalLoss: newGlobalLoss,
    accuracy: newAccuracy,
    participatingNodes: currentNodes.length,
    gradientUpdatesProcessed: Math.floor(15200 + Math.random() * 1800),
    byzantineFilteredUpdates: Math.floor(6 + Math.random() * 8),
    topCrossBorderTransferInsight: randomInsight,
  };

  return {
    updatedNodes,
    newRoundLog,
    newGlobalLoss,
    newAccuracy,
  };
}
