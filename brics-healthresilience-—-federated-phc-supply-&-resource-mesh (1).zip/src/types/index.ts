export type FacilityTier = 'PHC' | 'CHC' | 'Sub-Centre' | 'District Hospital';

export type StockHealthStatus = 'nominal' | 'low' | 'critical' | 'surplus';

export interface MedicineItem {
  id: string;
  name: string;
  category: 'Antibiotics' | 'Maternal Health' | 'Antimalarials' | 'Vaccines' | 'Fluids & ORS' | 'Chronic Care' | 'Emergency Antidotes';
  currentStock: number;
  unit: string;
  dailyBurnRate: number;
  daysOfStockRemaining: number;
  safetyThresholdDays: number;
  maxCapacity: number;
  requiresColdChain: boolean;
  coldChainTempC?: number; // e.g. 4.2°C
  batchNumber: string;
  expiryDate: string;
  status: StockHealthStatus;
}

export interface BedBreakdown {
  total: number;
  occupied: number;
  available: number;
  occupancyRate: number;
  stabilizationBeds: { total: number; occupied: number };
  maternityBeds: { total: number; occupied: number };
  pediatricBeds: { total: number; occupied: number };
  isolationBeds: { total: number; occupied: number };
}

export interface PersonnelRoster {
  medicalOfficers: { sanctioned: number; present: number };
  staffNurses: { sanctioned: number; present: number };
  anmMidwives: { sanctioned: number; present: number };
  labTechnicians: { sanctioned: number; present: number };
  pharmacists: { sanctioned: number; present: number };
  overallAttendanceRate: number;
  shiftStatus: 'Full Staffing' | 'Strained' | 'Critical Shortage';
}

export interface HealthFacility {
  id: string;
  name: string;
  code: string;
  country: 'India' | 'Brazil' | 'South Africa' | 'Russia' | 'China';
  state: string;
  district: string;
  subDistrict: string;
  tier: FacilityTier;
  catchmentPopulation: number;
  coordinates: { x: number; y: number; lat: number; lng: number }; // x,y for custom SVG interactive projection
  todayFootfall: number;
  avgDailyFootfall: number;
  feverClinicSurgeRate: number; // percentage vs normal e.g. +145%
  medicines: MedicineItem[];
  beds: BedBreakdown;
  personnel: PersonnelRoster;
  powerColdChainStatus: 'nominal' | 'battery_backup' | 'critical_power_loss';
  lastTelemetryPing: string;
  stockoutRiskScore: number; // 0 to 100
}

export interface TransferManifestItem {
  medicineId: string;
  medicineName: string;
  quantity: number;
  unit: string;
  requiresColdChain: boolean;
}

export interface TransferManifest {
  id: string;
  sourceFacilityId: string;
  sourceFacilityName: string;
  sourceDistrict: string;
  destFacilityId: string;
  destFacilityName: string;
  destDistrict: string;
  items: TransferManifestItem[];
  distanceKm: number;
  estimatedTransitMinutes: number;
  vehicleType: 'Refrigerated Cold-Chain Van' | 'Emergency Medical Courier' | 'Standard District Supply Truck';
  courierName: string;
  driverContact: string;
  status: 'suggested' | 'authorized' | 'in_transit' | 'delivered';
  urgency: 'critical' | 'high' | 'standard';
  projectedStockoutHours: number;
  createdAt: string;
  dispatchedAt?: string;
  completedAt?: string;
}

export interface EarlyWarningAlert {
  id: string;
  facilityId: string;
  facilityName: string;
  district: string;
  severity: 'critical' | 'warning' | 'advisory';
  category: 'Medicine Stockout' | 'Bed Saturation' | 'Personnel Deficit' | 'Cold-Chain Failure';
  headline: string;
  details: string;
  projectedCrisisTimeframe: string;
  impactedCohort: string;
  suggestedAction: string;
  timestamp: string;
}

export interface FederatedParticipantNode {
  id: string;
  country: string;
  nationalNetwork: string;
  flagEmoji: string;
  activeEdgePHCs: number;
  localDatasetSize: string;
  currentLoss: number;
  accuracyScore: number;
  privacyEpsilon: number; // differential privacy epsilon
  modelWeightsVersion: string;
  lastRoundContribution: string;
  status: 'synced' | 'training' | 'validating';
}

export interface FederatedRoundLog {
  roundNumber: number;
  timestamp: string;
  globalLoss: number;
  accuracy: number;
  participatingNodes: number;
  gradientUpdatesProcessed: number;
  byzantineFilteredUpdates: number;
  topCrossBorderTransferInsight: string;
}

export type EmergencyScenario = 
  | 'baseline' 
  | 'monsoon_dengue' 
  | 'flood_cholera' 
  | 'respiratory_surge' 
  | 'cold_chain_failure';

export interface CrisisDirectiveResponse {
  executiveSummary: string;
  clinicalPriorities: string[];
  logisticalActionPlan: string[];
  bricsTransferLearningNote: string;
}
